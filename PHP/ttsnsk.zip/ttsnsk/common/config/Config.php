<?php

class Config
{
    //設定必須：生成された帳票のExcel、PDF、バーコードPNGの保存ルート場所
    const REPORT_ROOT = 'D:\\work\\temp\\report\\';
    
    //設定必須：帳票印刷の場合、ファイル保存の臨時フォルダー
    const REPORT_TEMP = 'D:\\work\\temp\\report\\box\\';
    
    //設定必須：システム実施するとき、TimeZoneである。帳票名前やDB情報のキー生成に利用する。
    const TIME_ZONE='Asia/Shanghai';
    
    //DB接続情報
    public static $dbConfig=array (
        'db_host_name' => '192.168.234.4/myoracle',
        'db_user_name' => 'ttsnsk',
        'db_password' => 'ttsnsk',
    );
}

?>