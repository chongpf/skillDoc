<?php
class InternationalResource_EN{

   public static $resource = array(
   'A001_Menu_Login'=>'登录画面',
   'A001_Label_UserName'=>'用户名',
   'A001_Label_Password'=>'密码',
   'A001_Button_SignIn'=>'登录',
   'Cmn_Header_Link_Homepage'=>'主页',
   'Cmn_Header_Label_Homepage'=>'主页',
   'Cmn_Header_Link_Logout'=>'退出',
   );
}

?>