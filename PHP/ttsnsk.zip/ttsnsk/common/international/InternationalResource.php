<?php
require_once (dirname(__FILE__)) . '/../codemaster/CodeMaster.php';
require_once (dirname(__FILE__)) . '/InternationalResource_CN.php';
require_once (dirname(__FILE__)) . '/InternationalResource_EN.php';
require_once (dirname(__FILE__)) . '/InternationalResource_JP.php';
require_once (dirname(__FILE__)) . '/../session/SessionKey.php';

class InternationalResource
{

    public static $resource = array();

    public static function getContent($key)
    {
        if (count(self::$resource) == 0) {
            self::$resource = InternationalResource_CN::$resource;
            if (isset($_SESSION[SessionKey::Language])) {
                if ($_SESSION[SessionKey::Language] == CodeMaster::viewLanguage['en']) {
                    self::$resouce = InternationalResource_EN::$resource;
                } else if ($_SESSION[SessionKey::Language] == CodeMaster::viewLanguage['jp']) {
                    self::$resouce = InternationalResource_JP::$resource;
                }
            }
        }
        return self::$resource[$key];
    }
}

?>