<?php
class CodeMaster{

  public static $viewLanguage=array (
            'cn'=>'Chinese',
            'jp'=>'Japanese',
            'en'=>'English', 
          );

}

?>