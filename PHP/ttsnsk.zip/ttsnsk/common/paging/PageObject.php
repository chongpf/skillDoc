<?php
 
    class PageObject{
		
		var $page; //currentPage
		var $pageSize=10;//rows' size of one page
		
		var $startRow;
		var $endRow;
		
		var $allCount;//count of all result rows
		var $totalPage;

		var $firstPage;
		var $firstPageEnabled=true;
		
		var $prePage;
		var $prePageEnabled=true;
		
		var $nextPage;
		var $nextPageEnabled=true;
		
		var $lastPage;
		var $lastPageEnabled=true;
		
		var $pageNum=3;//in paging component,show the page'count such as  "first pre 4 5 6 next last"
		var $beginPage;//in paging component,show the page'count such as  "first pre 4 5 6 next last" ,beginPage=4
		var $endPage;//in paging component,show the page'count such as  "first pre 4 5 6 next last",endPage=6
		
		public function __construct($value=10){

			$this->pageSize=$value;
		}
		
		public function setPageCondition($page){
			if (empty($page)){  
                   $this->page = 1;  
            }else{
				   $this->page = $page;
			}

            $this->startRow = ($this->page - 1) * $this->pageSize + 1;  
            
            $this->endRow = $this->page * $this->pageSize; 
		}
		
		public function setPageResult($allCount){
			if (empty($allCount)){  
			   $this->allCount=0;
			}else{
				$this->allCount=$allCount;
			}
		    
			$this->totalPage = ceil($this->allCount / $this->pageSize); 
		
		    $this->firstPage=1;
			$this->lastPage=$this->totalPage;
		
            $this->prePage = $this->page - 1;  
            if ($this->prePage < 1){  
                $this->prePage = 1;
                $this->firstPageEnabled=false;
                $this->prePageEnabled=false;				
			 }else{
                $this->firstPageEnabled=true;
                $this->prePageEnabled=true;
			 }
 
            $this->nextPage = $this->page + 1;  
            if ($this->nextPage > $this->totalPage){  
                $this->nextPage = $this->totalPage;  
                $this->nextPageEnabled=false;
				$this->lastPageEnabled=false;
			}else{
			    $this->nextPageEnabled=true;
				$this->lastPageEnabled=true;	
			}
		
			 $this->beginPage = $this->page;  
             $this->endPage = $this->page + $this->pageNum -1;
             if ($this->endPage > $this->totalPage){  
                 $this->endPage = $this->totalPage;  
             }    
		}
	} 

?>