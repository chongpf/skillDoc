<?php
class SessionKey{

  const LoginUserToken='LoginUserToken';
  
  const LoginUserInfo='LoginUserInfo';
  
  const Language='Language';
  
}

?>