<?php
require_once (dirname(__FILE__)) . '/../../lib/PHPExcel-1.8/Classes/PHPExcel.php';
require_once (dirname(__FILE__)) . '/../../lib/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
require_once (dirname(__FILE__)) . '/../util/DateUtil.php';
require_once (dirname(__FILE__)) . '/../util/FileUtil.php';

class ReportDetail
{

    // reoport file
    var $objPHPExcel;

    // when create new excel,should use the property to save it.
    var $reportType;

    // when create new excel,should use the property to save it.
    var $reportKey;

    /**
     * when create new excel,should set the property to save it on the server.
     * ex: root\reportType\reportKey\reportType_reportKey.xlsx
     */
    public function __construct($reportType = null, $reportKey = null)
    {
        $this->reportType = $reportType;
        $this->reportKey = $reportKey;
    }

    public function loadTemplateFile($templateFileName)
    {
        $this->objPHPExcel = PHPExcel_IOFactory::load(FileUtil::getReportTemplatePath() . $templateFileName);
        $this->objPHPExcel->setActiveSheetIndex(0);
   
    }

    /**
     * write normal to excel
     * $position : the position ex: A1
     * $value : the value ex: 2017-11-11
     */
    public function writeCell($position, $value)
    {
        $this->objPHPExcel->getActiveSheet()->setCellValue($position, $value);
    }

    /**
     * write barcode to excel
     * $position : the position ex: A1
     * $barcode : the png of barcode ex: barcode.png
     */
    public function writeBarcode($position, $barcodeFilePath, $offsetX=0, $offsetY=0)
    {
        $objDrawing = new PHPExcel_Worksheet_Drawing();
        $objDrawing->setName('barcode');
        $objDrawing->setDescription('barcode');
        $objDrawing->setPath($barcodeFilePath);
        $objDrawing->setHeight(50);
        //$objDrawing->setWidth(200);
        $objDrawing->setOffsetX($offsetX);
        $objDrawing->setOffsetY($offsetY);
        
        $objDrawing->setCoordinates($position);
        $objDrawing->setWorksheet($this->objPHPExcel->getActiveSheet());
    }
    
    public function saveFile(){
        $path = FileUtil::getReportPath($this->reportType, $this->reportKey);
        $excelName = FileUtil::getReportExcelName($this->reportType, $this->reportKey);
        $pdfName = FileUtil::getReportPdfName($this->reportType, $this->reportKey);
        
        //write excel to server
        $excelWriter = PHPExcel_IOFactory::createWriter($this->objPHPExcel, 'Excel2007');
        $excelWriter->save($path.$excelName);
 
    }
    
    public function printDetail($filePath)
    {
        $htmlWriter = new PHPExcel_Writer_HTML(PHPExcel_IOFactory::load($filePath));
        $htmlWriter->setEmbedImages(true);
        $htmlWriter->save("php://output");

    }
    
    public function downloadDetail($filePath)
    {
        
        $objPHPExcel = PHPExcel_IOFactory::load($filePath);
        $filename = FileUtil::getFileName($filePath);
                
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        
    }
}

?>