<?php
require_once (dirname(__FILE__)) . '/../../lib/PHPExcel-1.8/Classes/PHPExcel.php';
require_once (dirname(__FILE__)) . '/../../lib/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
require_once (dirname(__FILE__)) . '/../util/DateUtil.php';
require_once (dirname(__FILE__)) . '/../util/FileUtil.php';

class ReportList
{

    // template file's path.include template file name.
    var $templateFileName;

    // the file name fo the file to be created
    var $fileName;

    // the file type of the report,such as .xls,.xlsx,.pdf etc
    var $fileType;

    public function __construct($templateFileName)
    {
        $this->templateFileName = $templateFileName;
    }

    /*
     * excel output
     * $tittleName : the tittle of the report
     * $colNameList :the excle's column name
     * $rowList : the row data to be writen to the excel
     */
    public function downloadExcel($tittleName, $colNameList, $rowList)
    {
        $this->generateFileName();
        
        $objPHPExcel = PHPExcel_IOFactory::load(FileUtil::getReportTemplatePath() . $this->templateFileName);
        $objPHPExcel->setActiveSheetIndex(0);
        
        // set tittle
        $objPHPExcel->getActiveSheet()->setCellValue($this->getColumnIndex(0) . '1', $tittleName);
        
        // set column name
        for ($i = 0; $i < count($colNameList); $i++) {
            $objPHPExcel->getActiveSheet()->setCellValue($this->getColumnIndex($i) . '3', $colNameList[$i]);
        }
        
        // set row data
        for ($j = 0; $j < count($rowList); $j ++) {
            $row = $j + 4; // from the 3th row,write data
            for ($k = 0; $k < count($colNameList); $k ++) {
                $col = $this->getColumnIndex($k);
                
                // set sytel of row list
                $sourceCell = $col . '4';
                $targetCell = $col . $row;
                $style = $objPHPExcel->getActiveSheet()->getStyle($sourceCell);
                $objPHPExcel->getActiveSheet()->duplicateStyle($style, $targetCell);
                
                // set data
                $objPHPExcel->getActiveSheet()->setCellValue($col . $row, $rowList[$j][$k]);
            }
        }
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $this->fileName . '.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit;
    }

    private function generateFileName()
    {
        $nameArray = explode('.', $this->templateFileName);
        $this->fileName = $nameArray[0] . '_' . DateUtil::getSystemDateTime();
        $this->fileType = $nameArray[1];
    }

    private function getColumnIndex($columnId)
    {
        $firstKey = '';
        $secondKey = '';
        
        $keyA = ord("A"); // A--65
        
        $firstByte = floor($columnId / 26);
        $secondByte = floor($columnId % 26);
        
        if ($firstByte == 0) {
            $firstKey = '';
            $secondKey = chr($keyA + $secondByte);
        } else {
            $firstKey = chr($keyA - 1 + $firstByte);
            $secondKey = chr($keyA + $secondByte);
        }
        
        return $firstKey . $secondKey;
    }
}

?>