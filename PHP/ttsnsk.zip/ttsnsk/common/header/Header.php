<?php 
require_once (dirname(__FILE__)).'/../international/InternationalResource.php';
?>
 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="./resource/pic/tts.jpg">
    <title><?php echo InternationalResource::getContent($pageId); ?></title>

    <!-- Bootstrap core CSS -->
    <!-- 
    <link href="./../../resource/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="./../../resource/bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	<script type="text/javascript" src="./../../resource/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
    <script type="text/javascript" src="./../../resource/bootstrap/js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="./../../resource/bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<script type="text/javascript" src="./../../resource/bootstrap-datetimepicker-master/js/locales/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8" ></script>
    <link href="./../../resource/css/common.css" rel="stylesheet">
    <script type="text/javascript" src="./../../resource/js/common.js"></script>
	 -->
	<link href="./resource/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="./resource/bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	<script type="text/javascript" src="./resource/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
    <script type="text/javascript" src="./resource/bootstrap/js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="./resource/bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<script type="text/javascript" src="./resource/bootstrap-datetimepicker-master/js/locales/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8" ></script>
    <link href="./resource/css/common.css" rel="stylesheet">
    <script type="text/javascript" src="./resource/js/common.js"></script>
	 
     <div class="container">
          <div class="row clearfix">
          <div class="col-md-12 column">
	      		<nav class="navbar navbar-default" role="navigation">
	      		    <div class="col-sm-1" style="float:left;margin-left:5px;">
	      				<ul class="nav navbar-nav navbar-left">
	      					<li class="active">
	      						 <a href="menu.php"><?php echo InternationalResource::getContent('Cmn_Header_Link_Homepage') ?></a>
	      					</li>
	      				</ul>
	      		    </div>
	      			<div class="col-sm-2" style="float:left;margin-top:15px;">
	      			   <?php 
	      			           if(isset($_SESSION[SessionKey::LoginUserInfo])){
	      			                echo $_SESSION[SessionKey::LoginUserInfo]->getUserName();
	      			           } 
	      			    ?>
	      			</div>
	      			<div class="col-sm-6" style="float:left;margin-top:5px;text-align:center;"><h4><?php echo InternationalResource::getContent($pageId) ?><h4></div>
	      			<div class="col-sm-2" style="float:right;">
	      				<ul class="nav navbar-nav navbar-right">
	      					<li>
	      						 <a href="login.php"><?php echo InternationalResource::getContent('Cmn_Header_Link_Logout') ?></a>
	      					</li>
	      				</ul>
	      			</div>
	      		</nav>
	      </div>
	      </div>
   </div>
 </head>