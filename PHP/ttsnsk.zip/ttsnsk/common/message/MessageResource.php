<?php
require_once (dirname(__FILE__)) . '/../codemaster/CodeMaster.php';

class MessageResource
{

    public static $resource = array();

    public static function getMessage($key)
    {
        if (count(self::$resource) == 0) {
            self::$resource = InternationalResource_CN::$resource;
            if (isset($_SESSION[SessionKey::Language])) {
                if ($_SESSION[SessionKey::Language] == CodeMaster::viewLanguage['en']) {
                    self::$resource = MessageResource_EN::$resource;
                } else if ($_SESSION[SessionKey::Language] == CodeMaster::viewLanguage['jp']) {
                    self::$resource = MessageResource_JP::$resource;
                }
            }
        }
        return self::$resource[$key];
    }
}

?>