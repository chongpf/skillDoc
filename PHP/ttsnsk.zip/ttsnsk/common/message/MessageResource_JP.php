<?php
class MessageResource_JP{

   public static $resource = array(
   'E-00001'=>'login error',
   'W-00002'=>'no data',
   );
}

?>