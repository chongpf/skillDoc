<?php
class MessageResource_EN{

   public static $resource = array(
   'E-00001'=>'login error',
   'W-00002'=>'no data',
   );
}

?>