<?php

// SQL对象类，每个SQL语句对应一个SqlObject
class SqlObject
{

    const SQLTYPE_SELECT = 'SELECT';

    const SQLTYPE_UPDATE = 'UPDATE';

    const SQLTYPE_DELETE = 'DELETE';

    const SQLTYPE_INSERT = 'INSERT';

    // Sql语句的类型：SELECT/UPDATE/DELETE/INSERT
    var $sqlType;

    // SQL语句 ex. ["select username,userID from temp where Create_Date between :parameter1 and :parameter2"]
    var $sql;

    // SQL语句中的参数 ex. [{key=":parameter1" value="2017-11-11"},{key=":parameter2" value="2017-12-12"}]
    var $parameters = array();

    // SQL语句执行的结果 ex. [{'username'=>'Michael','userID'=>'0001'},{'username'=>'Sofia','userID'=>'0002'}]
    var $result = array();

    // SQL语句执行结果的件数 ex. [2]
    var $count;

    public function __construct($sqlType)
    {
        $this->sqlType = $sqlType;
    }

    public function getSqlType()
    {
        return $this->sqlType;
    }

    public function setSqlType($sqlType)
    {
        $this->sqlType = $sqlType;
    }

    public function getSql()
    {
        return $this->sql;
    }

    public function setSql($sql)
    {
        $this->sql = $sql;
    }

    public function getParameters()
    {
        return $this->parameters;
    }

    public function addParameter($key, $value)
    {
        $this->parameters[$key] = $value;
    }

    public function getResult()
    {
        return $this->result;
    }

    public function setResult($result)
    {
        $this->result = $result;
    }

    public function getCount()
    {
        return $this->count;
    }

    public function setCount($count)
    {
        $this->count = $count;
    }
}
?>