<?php
require_once (dirname(__FILE__)) . '/../exception/ProjectException.php';
require_once (dirname(__FILE__)) . '/SqlObject.php';
require_once (dirname(__FILE__)) . '/../config/Config.php';

// 数据库连接，事务控制，以及SQL语句执行对象类
class DaoObject
{   
    // 数据库连接
    var $conn;

    // SQLstatement对象 //设置SQL语句对象 key:sqlIndex value:sqlObject
    var $sqlObjects = array();

    // 执行SQLStatement，可以一次执行多条sql。每一次执行会按一个事务进行处理，并把执行结果设置到SQLObject中。
    public function execute()
    {
        
        // 数据库连接
        $this->dbConnect();
        
        // loop the sql list,execuate
        foreach ($this->sqlObjects as $sqlIndex => $sqlObject) {
            
            // Prepare sql statement
            $statement = oci_parse($conn, $sqlObject->getSql());
            
            // bind parameters to sql statement
            if (count($sqlObject->getParameters()) > 0) {
                foreach ($sqlObject->getParameters() as $paramKey => $paramValue) {
                    oci_bind_by_name($statement, $paramKey, $paramValue);
                }
            }
            
            // execuate sql,do not commit immadiately
            $count = oci_execute($stmt, OCI_DEFAULT);
            
            // execuate sql failed,rollback
            if (! $count) {
                // DB rollback
                $this->dbRollback();
            }
            $sqlObject->setCount($count);
            
            if (SqlObject::SQLTYPE_SELECT == $sqlObject->getSqlType()) {
                // get all result
                oci_fetch_all($statement, $result);
                $sqlObject->setResult($result);
            }
        }
        
        // 事务提交
        $this->dbCommit();
    }

    // DB连接
    public function dbConnect()
    {
        $this->conn = oci_connect(Config::$dbConfig['db_user_name'], Config::$dbConfig['db_password'], Config::$dbConfig['db_host_name']);
        if (! $this->conn) {
            $e = oci_error();
            throw new ProjectException("db connect error:" . $e['message']);
        }
    }

    // DB事务提交
    public function dbCommit()
    {
        $committed = oci_commit($this->conn);
        if (! $committed) {
            $e = oci_error();
            throw new ProjectException("db commit error:" . $e['message']);
        }
    }

    // DB事务回滚
    public function dbRollback()
    {
        $rollback = oci_rollback($this->conn);
        if (! $rollback) {
            $e = oci_error();
            throw new ProjectException("db rollback error:" . $e['message']);
        }
    }

    // 设置SQL语句对象 key:sql value:sqlObject
    public function addSqlOjbect(SqlObject $sqlObject)
    {
        if (array_key_exists($sqlObject->getSql(), $this->sqlObjects)) {
            $this->sqlObjects[$sqlObject->getSql() . count($this->sqlObjects)] = $sqlObject;
        } else {
            $this->sqlObjects[$sqlObject->getSql()] = $sqlObject;
        }
    }
}

?>