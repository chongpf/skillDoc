<?php
require_once (dirname(__FILE__)).'/DateUtil.php';
 
    class KeyUtil{
        
        public static function generateKey(){
            $datetime = DateUtil::getSystemDateTime();
            $randNum = rand(100,999);
            return $datetime.$randNum;
        }
    }

?>