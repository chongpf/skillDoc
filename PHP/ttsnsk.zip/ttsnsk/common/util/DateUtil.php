<?php
class DateUtil{
    public static function getSystemDate(){
        date_default_timezone_set(Config::TIME_ZONE);
        $result = date('Ymd');
        return $result;
    }
    
    public static function getSystemDateTime(){
        date_default_timezone_set(Config::TIME_ZONE);
        $result = date('YmdHis');
        return $result;
        
    }
    
    public static function formatSystemDate($format){
        date_default_timezone_set(Config::TIME_ZONE);
        $result = date($format);
        return $result;
    }
    
    public static function formatDate($format,$dateValue){
        date_default_timezone_set(Config::TIME_ZONE);
        $result = '';
        if(preg_match('/^[\d]{8}$/', $dateValue)){
            $y = substr($dateValue, 0,4);
            $m= substr($dateValue, 4,2);
            $d= substr($dateValue, 6,2);
            $time = mktime(0,0,0,$m,$d,$y);
            return date($format,$time);
        }else{
            return '';
        }
      
    }
    
    public static function unformatDate($dateValue){
        date_default_timezone_set(Config::TIME_ZONE);
        $result = '';
        if(preg_match('/^[\d]{4}-[\d]{1,2}-[\d]{1,2}$/', $dateValue)){
            $arr=explode('-', $dateValue);
            if(len($arr[1])<2){
                $arr[1]='0'.$arr[1];
            }
            if(len($arr[2])<2){
                $arr[2]='0'.$arr[2];
            }
            return arr[0].arr[1].arr[2];
        }else{
            return '';
        }   
    }
    
}

?>