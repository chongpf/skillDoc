<?php
require_once (dirname(__FILE__)).'/../config/Config.php';

    class FileUtil{
        
        public static function getReportTemplatePath(){
            return (dirname(__FILE__)).'\\..\\..\\resource\\template\\';
        }
        
        public static function getReportPath($reprotType,$reportKey){
            $filePath = Config::REPORT_ROOT.$reprotType.'\\'.$reportKey.'\\';
            if(!file_exists($filePath)){
                mkdir($filePath,0777,true);
            }
            return $filePath;
        }
        public static function getReportTempPath(){
            $filePath = Config::REPORT_TEMP;
            if(!file_exists($filePath)){
                mkdir($filePath,0777,true);
            }
            return $filePath;
        }
        
        public static function getReportExcelName($reportType,$reportKey){
            return $reportType.'_'.$reportKey.'.xlsx';
            
        }
        public static function getReportPdfName($reportType,$reportKey){
            return $reportType.'_'.$reportKey.'.pdf';
            
        }
        
        public static function getBarcodeFileName($reportType,$reportKey){
            return $reportType.'_'.$reportKey.'.png';
        }
        
        public static function convExcel2PdfName($filename){
            return str_replace('.xlsx', '.pdf', $filename);
        }
        
        public static function getFileName($filePath){
            if(!empty($filePath)){
                $arr = explode(DIRECTORY_SEPARATOR, $filePath);
                return $arr[count($arr)-1];
            }else{
                return '';
            }
        }
    }

?>