<?php

 //系统异常捕捉器，主要用于预想外异常发生时进行系统异常显示   
  function projectExceptionHandler($exception) {
     //error message
	 $date=date('Y-m-d g-i-s');
     $errorMsg = $date.' '.$exception->getMessage();
     error_log($errorMsg);
     header(dirname(__FILE__).'/ProjectError.php');
 }

 // 设置用户定义的异常处理函数
 set_exception_handler("projectExceptionHandler");
?>