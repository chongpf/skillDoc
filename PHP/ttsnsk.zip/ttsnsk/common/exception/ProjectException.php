<?php
   
//系统自定义异常   
class ProjectException extends Exception{

  //把错误信息写入日志
  public function writeLog()
  {
     //error message
	 $date=date('Y-m-d g-i-s');
	 $file=$this->getFile();
	 $line=$this->getLine();
	 $message=$this->getMessage();
     $errorMsg = $date.' '.$file.' '.'Line='.$line.' '.$message;
     error_log($errorMsg);
  }  
  
}
?>