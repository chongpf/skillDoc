<?php
session_start();
    //ReportExcelSample.php
    require_once (dirname(__FILE__)).'/common/report/ReportList.php';
    
    //TEST1 -excel 2007
     $report = new ReportList('B001_AuthList.xlsx');
     $colNameList = array(
     'ColName.1',
     'ColName.2',
     'ColName.3',
     'ColName.4',
     'ColName.5',
     'ColName.6',
     'ColName.7',
     'ColName.8'
     );
     $rowList = array(
     array(
     '1',
     '2',
     '3',
     '4',
     '5',
     '6',
     '7',
     '8'
     ),
     array(
     '11',
     '22',
     '33',
     '44',
     '55',
     '66',
     '77',
     '88'
     )
     );
    $report->downloadExcel('firstReport', $colNameList, $rowList);

?>

<!DOCTYPE html>
<html lang="zh-CN">
    <p>test report excel</p>
</html>
