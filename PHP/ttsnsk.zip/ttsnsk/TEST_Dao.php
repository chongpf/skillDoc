<?php
session_start();
phpinfo();
// PageObjectSample.php
require_once (dirname(__FILE__)) . '/common/dao/DaoObject.php';
require_once (dirname(__FILE__)) . '/common/dao/SqlObject.php';

$sqlobject1 = new SqlObject('SELECT');
$sqlobject1->setSql('select * from CODE_MASTER where CATEGORY=:a and ITEM_CODE=:b');
$sqlobject1->addParameter(':a', '001');
$sqlobject1->addParameter(':b', '01');

$daoObject = new DaoObject();
$daoObject->addSqlojbect($sqlobject1);
$daoObject->execute();

foreach ($sqlobject1->getResult() as $row) {
    foreach($row as $item){
        echo var_dump($item);
    }
}

?>