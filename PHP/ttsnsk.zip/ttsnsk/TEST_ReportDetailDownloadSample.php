<?php
session_start();
    //ReportExcelSample.php
    require_once (dirname(__FILE__)).'/common/report/ReportDetail.php';
    require_once (dirname(__FILE__)).'/common/util/KeyUtil.php';
    require_once (dirname(__FILE__)).'/common/util/FileUtil.php';
    require_once (dirname(__FILE__)).'/common/util/DateUtil.php';
    require_once (dirname(__FILE__)).'/common/barcode/Barcode.php';
    
    $reportType = 'B004';
    $reportKey = KeyUtil::generateKey();

    $barcode = new Barcode();
    $filePath = FileUtil::getReportPath($reportType, $reportKey);
    $fileName = FileUtil::getBarcodeFileName($reportType, $reportKey);
    $text = $reportKey.'  hello';
    $barcode ->genBarcodeAndSave($filePath.$fileName, $text);
    
    $report = new ReportDetail($reportType,$reportKey);
    $report->loadTemplateFile('B004_ProcessSplit.xlsx');
    
    //mb_convert_encoding(var_export($values,true),"gb2312","utf-8");
    $report->writeCell('A3', 'Filed1');
    $report->writeCell('A4', 'Field2');
    $report->writeCell('A5', 'Field3');
    $report->writeCell('A6', 'Field4');
    $report->writeCell('A7', 'Field5');
    $report->writeCell('A8', 'Field6');
    $report->writeCell('B3', 1000);
    $report->writeCell('B4', '2017/11/25');
    $report->writeCell('B5', 'Hello');
    $report->writeCell('B6', 'comment123');
    $report->writeCell('B7', 1);
    $report->writeCell('B8', 1);
    $report->writeCell('C3', 'Filed7');
    $report->writeCell('C4', 'Field8');
    $report->writeCell('C5', 'Field9');
    $report->writeCell('C6', 'Field10');
    $report->writeCell('C7', 'Field11');
    $report->writeCell('C8', 'Field12');
    $report->writeCell('D3', 600);
    $report->writeCell('D4', '2018/01/25');
    $report->writeCell('D5', 'Hello world');
    $report->writeCell('D6', 'comment1234');
    $report->writeCell('D7', 11);
    $report->writeCell('D8', 111);
    $report->writeBarcode('A9', $filePath.$fileName,100,20);
    $report->saveFile();

    $path1 = FileUtil::getReportPath($reportType, $reportKey);
    $excelName1 = FileUtil::getReportExcelName($reportType, $reportKey);
    $report1 = new ReportDetail();
    $report1->downloadDetail($path1.$excelName1);
    
?>