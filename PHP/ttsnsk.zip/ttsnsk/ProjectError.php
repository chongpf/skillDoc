<?php
   session_start();
?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="./common/pic/tts.jpg">

    <title>错误画面</title>

    <!-- Bootstrap core CSS -->
    <link href="./common/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link href="./common/css/common.css" rel="stylesheet">
  </head>
<script type="text/javascript">
    function goto(url){
	    location.href=url;
	}
</script>

  <body>
   <div class="container">
   <div class="row clearfix">
     <div class="col-md-12 column">
			<nav class="navbar navbar-default" role="navigation">
			    <div class="col-sm-1" style="float:left;margin-left:5px;">
					<ul class="nav navbar-nav navbar-left">
						<li class="active">
							 <a href="menu.php">主页</a>
						</li>
					</ul>
			    </div>
				<div class="col-sm-2" style="float:left;margin-top:15px;">田中 太郎</div>
				<div class="col-sm-6" style="float:left;margin-top:5px;text-align:center;"><h4><h4></div>
				<div class="col-sm-2" style="float:right;">
					<ul class="nav navbar-nav navbar-right">
						<li>
							 <a href="logout.php">退出</a>
						</li>
					</ul>
				</div>
			</nav>
	</div>
	</div>
   </div>
   <div class="container">
   <div class="row clearfix">
		<div class="col-md-12 column">
				<div class="form-group">
					<label style="color:blue;">发生了错误，请联系管理员！</label>
				</div>
		</div>
	</div>
  </div>
  </body>
</html>
