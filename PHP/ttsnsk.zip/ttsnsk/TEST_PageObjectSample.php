<?php
session_start();
    //PageObjectSample.php
    require_once (dirname(__FILE__)).'/common/paging/PageObject.php';
    //require_once './common/paging/PageObject.php';
    $pageId='A001_PageName_Login';
   
    
    // set select condition
    $pageObject =new PageObject();
	$pageObject->setPageCondition($_GET['page']);
	//select rownum,xxx.* from(select rownum,xxx.* from xxx where xxx and rownum <= $pageObject->$endRow) where rownum > $pageObject->$startRow
	// select count(*)  from xxx where xxx 
	$allCount=100;
	$pageObject->setPageResult($allCount);

?>

<!DOCTYPE html>
<html lang="zh-CN">
<?php
require_once (dirname(__FILE__)).'/common/header/Header.php';
?>
  <body>
   <div class="container">
   <div class="row clearfix">
		<div class="col-md-12 column">
          <?php  
	         if($pageObject->allCount > 0){
				 echo '    <div class="form-group">';
				 echo '        <ul class="pagination">';

				 if($pageObject->firstPageEnabled){
					 echo '         <li><a href="?page='.$pageObject->firstPage.'">首页</a></li>';
				 }else{
					 echo '         <li disabled><a>首页</a></li>';
				 }
				 if($pageObject->prePageEnabled){
				     echo '         <li><a href="?page='.$pageObject->prePage.'">上一页</a></li>';				 	 
				 }else{
					 echo '         <li disabled><a>上一页</a></li>';
				 }
				 
				 for($index=$pageObject->beginPage; $index <= $pageObject->endPage; $index++){
					  echo '         <li><a href="?page='.$index.'">'.$index.'</a></li>';
				 }
				 
				 if($pageObject->nextPageEnabled){
					 echo '         <li><a href="?page='.$pageObject->nextPage.'">下一页</a></li>';
				 }else{
					 echo '         <li disabled><a>下一页</a></li>';
				 }
				 if($pageObject->lastPageEnabled){
				     echo '         <li><a href="?page='.$pageObject->lastPage.'">末页</a></li>';				 	 
				 }else{
					 echo '         <li disabled><a>末页</a></li>';
				 }

				 echo '        </ul>';
				 echo '    </div>';

			 }
	   ?>
	  </div>
	</div>
  </div>
  </body>
</html>
